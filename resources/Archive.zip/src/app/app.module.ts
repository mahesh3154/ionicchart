import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';
import { HttpModule} from '@angular/http';
import {HttpClientModule} from '@angular/common/http';

import { HomePage } from '../pages/home/home';
import { TabsPage } from '../pages/tabs/tabs';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { AciesServiceProvider } from '../providers/acies-service/acies-service';
import { MetricsPage } from '../pages/metrics/metrics';
import { MetricsPageModule } from '../pages/metrics/metrics.module';
import { SkuProductDetailsPageModule } from '../pages/sku-product-details/sku-product-details.module';
import { AutoCompleteModule } from 'ionic2-auto-complete';
import { HelpPageModule } from '../pages/help/help.module';
import { NotificationsPageModule } from '../pages/notifications/notifications.module';
import { HelpPage } from '../pages/help/help';
import { NotificationsPage } from '../pages/notifications/notifications';
import { SkuProductDetailsPage } from '../pages/sku-product-details/sku-product-details';
import { CompleteTestService } from '../services/completeTestService.service';



@NgModule({
  declarations: [
    MyApp,
  
   
    HomePage,
    TabsPage
  ],
  imports: [HttpModule,
    HelpPageModule,
    NotificationsPageModule,
    AutoCompleteModule,
    SkuProductDetailsPageModule,
    MetricsPageModule,
    HttpClientModule,
    
    BrowserModule,
    IonicModule.forRoot(MyApp, {
      tabsHideOnSubPages:true
    })
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp,
    
    HelpPage,
    NotificationsPage,
    
    HomePage,
    TabsPage,
    SkuProductDetailsPage,
    MetricsPage
  ],
  providers: [AciesServiceProvider,
    StatusBar,
    CompleteTestService,
    SplashScreen,
    {provide: ErrorHandler, useClass: IonicErrorHandler},
    AciesServiceProvider
  ]
})
export class AppModule {}
