import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SkuProductDetailsPage } from './sku-product-details';

@NgModule({
  declarations: [
    SkuProductDetailsPage,
  ],
  imports: [
    IonicPageModule.forChild(SkuProductDetailsPage),
  ],
})
export class SkuProductDetailsPageModule {}
