import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams } from 'ionic-angular';
import { AciesServiceProvider } from '../../providers/acies-service/acies-service';

/**
 * Generated class for the SkuProductDetailsPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-sku-product-details',
  templateUrl: 'sku-product-details.html',
})
export class SkuProductDetailsPage {
  
  sku: any;

  constructor(public navCtrl: NavController, public navParams: NavParams, public aciesServiceProvider: AciesServiceProvider) {
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad SkuProductDetailsPage');
  }
  getSkuForecast(sku,location){
    this.aciesServiceProvider.getSkuForecast(sku,location).subscribe(response =>{
      this.sku=response;
    });
      }

}
