import { Component } from '@angular/core';
import { HomePage } from '../home/home';
import { NotificationsPage } from '../notifications/notifications';
import { HelpPage } from '../help/help';


@Component({
  templateUrl: 'tabs.html'
})
export class TabsPage {

  tab1Root = HomePage;
  tab2Root = NotificationsPage;
  tab3Root = HelpPage;
  

  constructor() {

  }s
}
