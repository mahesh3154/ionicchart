import { HttpClient } from '@angular/common/http';

import { Injectable } from '@angular/core';

/*
  Generated class for the AciesServiceProvider provider.

  See https://angular.io/guide/dependency-injection for more info on providers
  and Angular DI.
*/
@Injectable()
export class AciesServiceProvider {
  forecastAccuracy(selectedValue: any): any {
    console.log("service", selectedValue );
  } 
   totalsales(selectedValue): any {
    console.log("service", selectedValue );
  }  

  constructor(public http: HttpClient) {
    console.log('Hello AciesServiceProvider Provider');
  }
  getSkuForecast(sku,location){
     return sku;
  }

}
