import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { ActionSheetController } from 'ionic-angular'
import {CompleteTestService} from '../../services/CompleteTestService.service'
@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  name:any;
  gender :any;
  someCondition:any;
  searchQuery: string = '';
  topics: string[];
  constructor(public navCtrl: NavController, public actionSheetCtrl: ActionSheetController, public completeTestService:CompleteTestService) {
    this.gender  = "f";
    
    this.someCondition = true;
   }
   test(){
     alert('hi')
   }
    generateTopics() {
      this.topics = [
        'Storage in Ionic 2',
        'Ionic 2 - calendar',
        'Creating a Android application using ionic framework.',
        'Identifying app resume event in ionic - android',
        'What is hybrid application and why.?',
        'Procedure to remove back button text',
        'How to reposition ionic tabs on top position.',
        'Override Hardware back button in cordova based application - Ionic',
        'Drupal 8: Enabling Facets for Restful web services',
        'Drupal 8: Get current user session',
        'Drupal 8: Programatically create Add another field - Example',  
      ];
    }
   
  
    getItems(keyword){
      this.completeTestService.getResults('test').subscribe((res) => {
        console.log(res)
    },
        (error) => {
            console.log('unable to load taxpayer data');
        }
    );
          
}
  }